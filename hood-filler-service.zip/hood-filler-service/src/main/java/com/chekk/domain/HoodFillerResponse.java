package com.chekk.domain;

import java.util.List;

public class HoodFillerResponse {
    private List<Integer> presentWeights;

    // Constructor
    public HoodFillerResponse(List<Integer> presentWeights) {
        this.presentWeights = presentWeights;
    }

    // Getter
    public List<Integer> getPresentWeights() {
        return presentWeights;
    }

    // Setter
    public void setPresentWeights(List<Integer> presentWeights) {
        this.presentWeights = presentWeights;
    }
}

