package com.chekk.domain;

import java.util.List;

/**
 * POJO class to handle the Request/Model class
 * @author Maneesh
 *
 */
public class HoodFillerRequest {
	private int hood_capacity;
	private List<Integer> present_weights;
	
	// Constructor that accepts hoodCapacity and presentWeights
    public HoodFillerRequest(int hood_capacity, List<Integer> present_weights) {
        this.hood_capacity = hood_capacity;
        this.present_weights = present_weights;
    }
    
    public HoodFillerRequest() {
    }

	public int getHood_capacity() {
		return hood_capacity;
	}

	public void setHood_capacity(int hood_capacity) {
		this.hood_capacity = hood_capacity;
	}

	public List<Integer> getPresent_weights() {
		return present_weights;
	}

	public void setPresent_weights(List<Integer> present_weights) {
		this.present_weights = present_weights;
	}


}
