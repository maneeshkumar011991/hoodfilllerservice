package com.chekk.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Controller class to handle all the hood filler related calls
 * @author Maneesh
 *
 */

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chekk.domain.HoodFillerRequest;
import com.chekk.domain.HoodFillerResponse;
import com.chekk.service.HoodFillerService;

/**
 * Controller class to handle the Hood Filler calculations
 * @author Maneesh
 *
 */
@RestController
@RequestMapping("/hoodfiller")
public class HoodFillerController {
	
	@Autowired
	HoodFillerService hoodFillerService;

	/**
	 * Process the request and return the result of calculatedMinimumPresents
	 * @param request
	 * @return
	 * @throws Exception 
	 */
    @PostMapping
    public ResponseEntity<HoodFillerResponse> fillHood(@RequestBody HoodFillerRequest request) throws Exception {
    	
    	List<Integer> result = hoodFillerService.fillHood(request.getHood_capacity(), request.getPresent_weights());
        HoodFillerResponse response = new HoodFillerResponse(result);
        return ResponseEntity.ok(response);
    }

    
}

