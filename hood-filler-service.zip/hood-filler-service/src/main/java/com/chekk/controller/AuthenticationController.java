package com.chekk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chekk.domain.JwtRequest;
import com.chekk.security.JwtTokenUtil;

/**
 * This controller will issue JWT tokens. 
 * We'll assume that "Santa" is the only user allowed, with a predefined username and password.
 * @author Maneesh
 *
 */
@RestController
@RequestMapping("/authenticate")
public class AuthenticationController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    
    @Value("${santa.username}")
    private String userName;

    @Value("${santa.password}")
    private String password;

    @PostMapping
    public ResponseEntity<?> createToken(@RequestBody JwtRequest request) {
        // Simple hardcoded check for Santa
        if (userName != null && password != null && 
        		(userName.equalsIgnoreCase(request.getUsername()) && password.equals(request.getPassword()))) {
            String token = jwtTokenUtil.generateToken(request.getUsername());
            return ResponseEntity.ok(new AuthResponse(token));
        }
        return ResponseEntity.status(401).body("Invalid credentials");
    }

    public static class AuthResponse {
        private String token;

        public AuthResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }
    }
}

