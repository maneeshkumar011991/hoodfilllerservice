package com.chekk.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

/**
 * Service class to handle the business logic
 * @author Maneesh
 *
 */
@Service
public class HoodFillerService {

	/**
     * Method to return the final result
     * @param hoodCapacity
     * @param presentWeights
	 * @return 
	 * @throws Exception 
     */
	public List<Integer> fillHood(int hoodCapacity, List<Integer> presentWeights) throws Exception {
		 if (hoodCapacity <= 0) {
			 throw new Exception("Incorrect hood capacity, pls correct and try again");
		 } else if (presentWeights == null || presentWeights.isEmpty()) {
			 throw new Exception("Present weights list cannot be empty.");
		 }
		 return calculateMinimumPresents(hoodCapacity, presentWeights);		
	}
	
	/**
     * Calculate the minimum presents
     * @param capacity
     * @param presentWeights
     * @return
     */
    private List<Integer> calculateMinimumPresents(int capacity, List<Integer> presentWeights) {
    	// Sort the present weights in descending order to start with the largest weights first
        Collections.sort(presentWeights, Collections.reverseOrder());

        List<Integer> selectedPresents = new ArrayList<>();
        int remainingCapacity = capacity;

        for (int weight : presentWeights) {
            // While the present weight can fit in the remaining capacity, add it to the list
            while (remainingCapacity >= weight) {
                selectedPresents.add(weight);
                remainingCapacity -= weight;
            }
            if (remainingCapacity == 0) break;  // Exit early if we've filled the hood
        }

        return selectedPresents;
    }

}
