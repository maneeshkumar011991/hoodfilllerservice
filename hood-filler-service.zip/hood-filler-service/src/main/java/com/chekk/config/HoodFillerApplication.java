package com.chekk.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * SpringBootApplication class for Hood filler App
 * @author Maneesh
 *
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.chekk")
public class HoodFillerApplication {

	public static void main(String[] args) {
        SpringApplication.run(HoodFillerApplication.class, args);
    }
}
