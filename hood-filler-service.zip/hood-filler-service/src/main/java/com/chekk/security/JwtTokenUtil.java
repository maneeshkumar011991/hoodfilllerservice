package com.chekk.security;

import java.security.SecureRandom;
import java.util.Date;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * Utility class to generate and validate JWT tokens. 
 * @author Maneesh
 *
 */
@Component
public class JwtTokenUtil {

    private final static SecretKey SECRET_KEY = generateStrongKey();
    
    @Value("${jwt.expiration}")
    private long jwtExpiration;
	    
    /**
     * Generate a Strong Random Secret Key
     * @return
     */
    private static SecretKey generateStrongKey() {
        SecureRandom secureRandom = new SecureRandom();
        byte[] keyBytes = new byte[32]; // 256 bits = 32 bytes
        secureRandom.nextBytes(keyBytes);
        return new SecretKeySpec(keyBytes, SignatureAlgorithm.HS256.getJcaName());
    }    

    public String generateToken(String subject) {
        // Convert the secret key string to bytes and create a SecretKeySpec
        return Jwts.builder()
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
                .signWith(SECRET_KEY, SignatureAlgorithm.HS256) // Use the key here
                .compact();
    }

    public boolean validateToken(String token, String username) {
        final String tokenUsername = extractUsername(token);
        return (tokenUsername.equals(username) && !isTokenExpired(token));
    }

    public String extractUsername(String token) {
        return parseAndValidate(token).getSubject();
    }

    private boolean isTokenExpired(String token) {
        return parseAndValidate(token).getExpiration().before(new Date());
    }

    // Method to parse and validate the token
    public Claims parseAndValidate(String token) {
        // Convert the secret key string to bytes and create a SecretKeySpec
 
        // Parse the token
        return Jwts.parserBuilder()
                .setSigningKey(SECRET_KEY) // Use the key object here
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}
