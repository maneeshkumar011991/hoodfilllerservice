package com.chekk.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.chekk.domain.HoodFillerRequest;
import com.chekk.domain.HoodFillerResponse;
import com.chekk.service.HoodFillerService;

/**
 * Test class which contains tests for HoodFillerController
 * @author Maneesh
 *
 */
@ExtendWith(MockitoExtension.class)
public class HoodFillerControllerTest {

	@InjectMocks
	HoodFillerController hoodFillerController; 
	
	@Mock
	private HoodFillerService hoodFillerService;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}


    @Test
    public void testFillHood_success() throws Exception {
        // Arrange
        HoodFillerRequest request = new HoodFillerRequest(41, Arrays.asList(2, 5, 10, 50, 100));
        List<Integer> result = Arrays.asList(10,10,10,5,2,2,2);
        when(hoodFillerService.fillHood(request.getHood_capacity(), request.getPresent_weights())).thenReturn(result);
        ResponseEntity<HoodFillerResponse> response = hoodFillerController.fillHood(request);
        assertEquals(response.getBody().getPresentWeights().get(5), 2);
        assertEquals(response.getBody().getPresentWeights().get(0), 10);        
    }
    
    @Test
    public void testFillHood_failure() throws Exception {
        // Arrange
        HoodFillerRequest request = new HoodFillerRequest(41, Arrays.asList(2, 5, 10, 50, 100));
        List<Integer> incorrectResult = Arrays.asList(10,10,10,5,2,2,3);
        when(hoodFillerService.fillHood(request.getHood_capacity(), request.getPresent_weights())).thenReturn(incorrectResult);
        ResponseEntity<HoodFillerResponse> response = hoodFillerController.fillHood(request);
        // Assert that the expected and actual values do not match
        assertNotEquals(response.getBody().getPresentWeights().get(1), 2);  // This will fail as the value at index 5 is 3, not 2
        assertNotEquals(response.getBody().getPresentWeights().get(5), 10); // This will fail as the value at index 0 is 10, but the test expects something else
    }

    

}
