package com.chekk.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Test class which contains several tests for HoodFillerService methods
 * @author Maneesh
 *
 */
@ExtendWith(MockitoExtension.class)
public class HoodFillerServiceTest {

    @InjectMocks
    private HoodFillerService hoodFillerService;

    @BeforeEach
    public void setUp() {
        // Initialize any necessary setup here if needed
    }

    @Test
    public void testFillHood_singleWeight_exactMatch() throws Exception {
        int hoodCapacity = 10;
        List<Integer> presentWeights = Collections.singletonList(10);

        List<Integer> result = hoodFillerService.fillHood(hoodCapacity, presentWeights);

        assertEquals(Collections.singletonList(10), result, "The method should return a single present if it exactly matches the hood capacity.");
    }

    @Test
    public void testFillHood_singleWeight_noMatch() throws Exception {
        int hoodCapacity = 15;
        List<Integer> presentWeights = Collections.singletonList(10);

        List<Integer> result = hoodFillerService.fillHood(hoodCapacity, presentWeights);

        assertFalse(result.isEmpty(), "The method should return an empty list when no single present can exactly match the hood capacity.");
    }

    @Test
    public void testFillHood_emptyPresentWeights() throws Exception {
        int hoodCapacity = 20;
        List<Integer> presentWeights = Collections.emptyList();

        // Expect the method to throw IllegalArgumentException when presentWeights is empty
        Exception exception = assertThrows(Exception.class, () -> {
            hoodFillerService.fillHood(hoodCapacity, presentWeights);
        });

        // Verify the exception message
        assertEquals("Present weights list cannot be empty.", exception.getMessage());
    }
    
    @Test
    public void testFillHood_hoodCapacityPassedAsZero() throws Exception {
        int hoodCapacity = 0;
        List<Integer> presentWeights = Collections.emptyList();

        // Expect the method to throw IllegalArgumentException when presentWeights is empty
        Exception exception = assertThrows(Exception.class, () -> {
            hoodFillerService.fillHood(hoodCapacity, presentWeights);
        });

        // Verify the exception message
        assertEquals("Incorrect hood capacity, pls correct and try again", exception.getMessage());
    }

    @Test
    public void testFillHood_largeCapacity() throws Exception {
        int hoodCapacity = 1000;
        List<Integer> presentWeights = Arrays.asList(100, 200, 300, 400);

        List<Integer> result = hoodFillerService.fillHood(hoodCapacity, presentWeights);

        assertEquals(Arrays.asList(400, 400, 200), result, "The method should return the minimal number of presents that exactly fill a large hood.");
    }

    @Test
    public void testFillHood_edgeCase_smallCapacity() throws Exception {
        int hoodCapacity = 1;
        List<Integer> presentWeights = Arrays.asList(1, 2, 3);

        List<Integer> result = hoodFillerService.fillHood(hoodCapacity, presentWeights);

        assertEquals(Collections.singletonList(1), result, "The method should return the exact single present that matches the small hood capacity.");
    }
}
